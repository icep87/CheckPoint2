﻿using System;
namespace CheckPoint2
{
    public class Product
    {
        public string Name { get; set; }
        public float Price { get; set; }

        public Product()
        {
        }
    }
}
